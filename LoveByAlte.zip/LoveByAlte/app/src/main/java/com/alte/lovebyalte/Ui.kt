package com.alte.lovebyalte

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.TextStyle as JTextStyle
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val RU: Locale = Locale.forLanguageTag("ru")

data class NavTab(val label: String, val icon: ImageVector)

private val tabs = listOf(
    NavTab("Мелочи", Icons.Rounded.Notifications),
    NavTab("Планы", Icons.Rounded.Checklist),
    NavTab("Привычки", Icons.Rounded.LocalFireDepartment),
    NavTab("Досуг", Icons.Rounded.Lightbulb),
    NavTab("Сказать", Icons.Rounded.ChatBubble)
)

// ───────────────────────── Корень приложения ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoveApp(vm: AppVm) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PulsingHeart()
                        Spacer(Modifier.width(8.dp))
                        Text("LoveByAlte", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label, maxLines = 1) }
                    )
                }
            }
        },
        floatingActionButton = {
            AnimatedVisibility(
                visible = tab != 3,
                enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(),
                exit = scaleOut() + fadeOut()
            ) {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Rounded.Add, contentDescription = "Добавить")
                }
            }
        }
    ) { pad ->
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.padding(pad),
            transitionSpec = {
                val d = if (targetState > initialState) 1 else -1
                (slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { it / 5 * d } + fadeIn(tween(380))) togetherWith
                    (slideOutHorizontally(tween(260)) { -it / 5 * d } + fadeOut(tween(200)))
            },
            label = "tabs"
        ) { t ->
            when (t) {
                0 -> ItemsScreen(Kind.REMINDER, vm, "Мелочи на сегодня", "Чтобы ничего не забыть", "Пока пусто.\nНажми +, чтобы добавить напоминание", "🔔")
                1 -> ItemsScreen(Kind.PLAN, vm, "Наши планы", "Всё, что хотим сделать вместе", "Список планов пуст.\nЗапиши первую мечту", "🗺️")
                2 -> HabitsScreen(vm)
                3 -> IdeasScreen(vm)
                else -> ItemsScreen(Kind.SAY, vm, "Нужно сказать", "Тёплые слова вовремя", "Пока нечего говорить.\nДобавь то, что важно не забыть", "💬") { SayHint(vm) }
            }
        }
    }

    if (showAdd) {
        if (tab == 2) {
            AddHabitDialog(onDismiss = { showAdd = false }) { n, e -> vm.addHabit(n, e); showAdd = false }
        } else {
            val kind = when (tab) { 0 -> Kind.REMINDER; 1 -> Kind.PLAN; else -> Kind.SAY }
            AddItemDialog(kind, onDismiss = { showAdd = false }) { text, time ->
                vm.addItem(text, kind, time); showAdd = false
            }
        }
    }
}

// ───────────────────────── Анимационные помощники ─────────────────────────

fun Modifier.bouncy(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.96f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "press"
    )
    this.scale(s).clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun StaggerIn(index: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index.coerceAtMost(8) * 55L)
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn(tween(400)) +
            slideInVertically(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) { it / 3 } +
            scaleIn(initialScale = 0.9f)
    ) { content() }
}

@Composable
fun PulsingHeart() {
    val t = rememberInfiniteTransition(label = "heart")
    val s by t.animateFloat(
        1f, 1.25f,
        infiniteRepeatable(tween(750, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "beat"
    )
    Icon(
        Icons.Rounded.Favorite, null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(26.dp).scale(s)
    )
}

@Composable
fun EmptyState(emoji: String, text: String) {
    val t = rememberInfiniteTransition(label = "bob")
    val y by t.animateFloat(
        -8f, 8f,
        infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "y"
    )
    Column(
        Modifier.fillMaxWidth().padding(vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 64.sp, modifier = Modifier.offset(y = y.dp))
        Spacer(Modifier.height(12.dp))
        Text(
            text, textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun HeaderCard(title: String, subtitle: String, done: Int, total: Int) {
    val target = if (total == 0) 0f else done.toFloat() / total
    val p by animateFloatAsState(target, tween(900, easing = FastOutSlowInEasing), label = "ring")
    Card(
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(subtitle, style = MaterialTheme.typography.bodyMedium)
            }
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { p },
                    modifier = Modifier.size(68.dp),
                    strokeWidth = 8.dp,
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                    strokeCap = StrokeCap.Round
                )
                Text("$done/$total", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun CheckCircle(checked: Boolean) {
    val fill by animateColorAsState(
        if (checked) MaterialTheme.colorScheme.primary else Color.Transparent, tween(300), label = "fill"
    )
    val edge by animateColorAsState(
        if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, tween(300), label = "edge"
    )
    val s by animateFloatAsState(
        if (checked) 1f else 0f, spring(Spring.DampingRatioMediumBouncy), label = "tick"
    )
    Box(
        Modifier.size(28.dp).clip(CircleShape).background(fill).border(2.dp, edge, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Rounded.Check, null,
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(18.dp).scale(s)
        )
    }
}

// ───────────────────────── Списки: мелочи, планы, «сказать» ─────────────────────────

@Composable
fun ItemsScreen(
    kind: Kind, vm: AppVm, title: String, subtitle: String, empty: String, emoji: String,
    extra: (@Composable () -> Unit)? = null
) {
    val list = vm.items.filter { it.kind == kind }
        .sortedWith(compareBy({ it.done }, { it.time ?: Long.MAX_VALUE }, { -it.id }))
    LazyColumn(
        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "header") {
            HeaderCard(title, subtitle, list.count { it.done }, list.size)
        }
        if (extra != null) item(key = "extra") { extra() }
        if (list.isEmpty()) item(key = "empty") { EmptyState(emoji, empty) }
        itemsIndexed(list, key = { _, it -> it.id }) { i, it ->
            StaggerIn(i, Modifier.animateItem()) {
                ItemCard(it, onToggle = { vm.toggle(it.id) }, onDelete = { vm.delete(it.id) })
            }
        }
    }
}

@Composable
fun ItemCard(item: Item, onToggle: () -> Unit, onDelete: () -> Unit) {
    val bg by animateColorAsState(
        if (item.done) MaterialTheme.colorScheme.surfaceContainerHigh
        else MaterialTheme.colorScheme.secondaryContainer,
        tween(400), label = "bg"
    )
    val alpha by animateFloatAsState(if (item.done) 0.55f else 1f, tween(400), label = "alpha")
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        modifier = Modifier.fillMaxWidth().bouncy(onToggle)
    ) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            CheckCircle(item.done)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.text,
                    style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (item.done) TextDecoration.LineThrough else null,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha)
                )
                if (item.time != null) {
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Schedule, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(4.dp))
                        Text(
                            SimpleDateFormat("d MMM, HH:mm", RU).format(Date(item.time)),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Rounded.Delete, "Удалить", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private val sayIdeas = listOf(
    "Спасибо, что ты рядом 💛",
    "Мне с тобой очень повезло",
    "Я горжусь тобой",
    "Ты делаешь мои дни лучше",
    "Я скучаю по тебе",
    "Ты классно выглядишь сегодня",
    "Люблю, как ты смеёшься",
    "С тобой мне спокойно"
)

@Composable
fun SayHint(vm: AppVm) {
    var idea by rememberSaveable { mutableStateOf(sayIdeas.random()) }
    var spins by rememberSaveable { mutableIntStateOf(0) }
    val rot by animateFloatAsState(spins * 360f, tween(600, easing = FastOutSlowInEasing), label = "rot")
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("Подсказка", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            AnimatedContent(
                targetState = idea,
                transitionSpec = { (fadeIn(tween(300)) + slideInVertically { it / 3 }) togetherWith fadeOut(tween(150)) },
                label = "hint"
            ) { Text(it, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(8.dp))
            Row {
                IconButton(onClick = {
                    idea = sayIdeas.filter { it != idea }.random(); spins++
                }) { Icon(Icons.Rounded.Shuffle, "Другая", Modifier.rotate(rot)) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { vm.addItem(idea, Kind.SAY, null) }) { Text("Добавить в список") }
            }
        }
    }
}

// ───────────────────────── Привычки ─────────────────────────

fun streakOf(days: Set<String>): Int {
    var d = LocalDate.now()
    if (d.toString() !in days) d = d.minusDays(1)
    var n = 0
    while (d.toString() in days) { n++; d = d.minusDays(1) }
    return n
}

@Composable
fun HabitsScreen(vm: AppVm) {
    val today = LocalDate.now().toString()
    LazyColumn(
        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "header") {
            HeaderCard("Привычки", "Маленькие шаги — вместе", vm.habits.count { today in it.days }, vm.habits.size)
        }
        if (vm.habits.isEmpty()) item(key = "empty") {
            EmptyState("🔥", "Привычек пока нет.\nНажми +, чтобы начать серию")
        }
        itemsIndexed(vm.habits, key = { _, h -> h.id }) { i, h ->
            StaggerIn(i, Modifier.animateItem()) { HabitCard(h, vm) }
        }
    }
}

@Composable
fun HabitCard(h: Habit, vm: AppVm) {
    val streak = streakOf(h.days)
    val today = LocalDate.now()
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) { Text(h.emoji, fontSize = 24.sp) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(h.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val flame = rememberInfiniteTransition(label = "flame")
                        val fs by flame.animateFloat(
                            0.9f, 1.15f,
                            infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "fs"
                        )
                        Icon(
                            Icons.Rounded.LocalFireDepartment, null,
                            tint = if (streak > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(18.dp).scale(if (streak > 0) fs else 1f)
                        )
                        Spacer(Modifier.width(4.dp))
                        AnimatedContent(
                            targetState = streak,
                            transitionSpec = { (slideInVertically { it } + fadeIn()) togetherWith (slideOutVertically { -it } + fadeOut()) },
                            label = "streak"
                        ) { Text("$it дн. подряд", style = MaterialTheme.typography.labelLarge) }
                    }
                }
                IconButton(onClick = { vm.deleteHabit(h.id) }) {
                    Icon(Icons.Rounded.Delete, "Удалить", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for (i in 6 downTo 0) {
                    val d = today.minusDays(i.toLong())
                    DayDot(d, d.toString() in h.days, i == 0) { vm.toggleDay(h.id, d.toString()) }
                }
            }
        }
    }
}

@Composable
fun DayDot(date: LocalDate, done: Boolean, isToday: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
        tween(300), label = "dot"
    )
    val s by animateFloatAsState(
        if (done) 1f else 0.92f, spring(Spring.DampingRatioHighBouncy), label = "dotScale"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            date.dayOfWeek.getDisplayName(JTextStyle.SHORT, RU),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier.size(38.dp).scale(s).clip(CircleShape).background(bg)
                .then(if (isToday) Modifier.border(2.dp, MaterialTheme.colorScheme.tertiary, CircleShape) else Modifier)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (done) Icon(Icons.Rounded.Check, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onPrimary)
            else Text(date.dayOfMonth.toString(), style = MaterialTheme.typography.labelMedium)
        }
    }
}

// ───────────────────────── Генератор идей для досуга ─────────────────────────

private val ideaMap = mapOf(
    "Дома" to listOf(
        "🎬 Киномарафон под пледами с попкорном",
        "🍕 Готовим пиццу с нуля и украшаем по-своему",
        "🎲 Вечер настолок с призом победителю",
        "🕯️ Ужин при свечах дома, телефоны в сторону",
        "🎨 Рисуем друг друга и сравниваем портреты",
        "📖 Читаем вслух одну книгу по очереди"
    ),
    "Романтика" to listOf(
        "🌅 Встретить рассвет или закат в красивом месте",
        "💌 Написать друг другу письма и обменяться",
        "🍷 Устроить пикник на крыше или в парке",
        "📸 Фотосессия вдвоём в любимом районе",
        "🌠 Вечер под звёздами с чаем в термосе",
        "💃 Станцевать медленный танец на кухне"
    ),
    "Активно" to listOf(
        "🚴 Велопрогулка по новому маршруту",
        "🥾 Поход на целый день с бутербродами",
        "🛼 Покататься на роликах или коньках",
        "🧗 Попробовать скалодром",
        "🏊 Сходить в бассейн или на озеро",
        "🏃 Пробежка вдвоём и завтрак после"
    ),
    "Бюджетно" to listOf(
        "☕ Кофе на вынос и прогулка без цели",
        "🏛️ Бесплатный музей или выставка",
        "🧺 Блошиный рынок: найти самую странную вещь",
        "🍦 Охота за самым вкусным мороженым в городе",
        "🌳 Пикник с тем, что нашлось в холодильнике",
        "🎧 Обменяться плейлистами и послушать вместе"
    )
)
private val ideaCats = listOf("Всё") + ideaMap.keys

private fun pickIdea(cat: String, current: String): String {
    val pool = if (cat == "Всё") ideaMap.values.flatten() else ideaMap[cat].orEmpty()
    return pool.filter { it != current }.random()
}

@Composable
fun IdeasScreen(vm: AppVm) {
    var cat by rememberSaveable { mutableStateOf("Всё") }
    var idea by rememberSaveable { mutableStateOf(pickIdea("Всё", "")) }
    var spins by rememberSaveable { mutableIntStateOf(0) }
    var added by remember { mutableStateOf(false) }
    val rot by animateFloatAsState(spins * 360f, tween(700, easing = FastOutSlowInEasing), label = "dice")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Чем займёмся?", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ideaCats.forEach { c ->
                FilterChip(
                    selected = c == cat,
                    onClick = { cat = c; idea = pickIdea(c, idea); spins++; added = false },
                    label = { Text(c) }
                )
            }
        }
        Card(
            shape = RoundedCornerShape(40.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
            modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp)
        ) {
            Box(Modifier.fillMaxWidth().heightIn(min = 240.dp).padding(28.dp), contentAlignment = Alignment.Center) {
                AnimatedContent(
                    targetState = idea,
                    transitionSpec = {
                        (fadeIn(tween(350)) + scaleIn(initialScale = 0.8f, animationSpec = spring(Spring.DampingRatioMediumBouncy))) togetherWith
                            (fadeOut(tween(150)) + scaleOut(targetScale = 0.9f))
                    },
                    label = "idea"
                ) {
                    Text(
                        it, textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { idea = pickIdea(cat, idea); spins++; added = false },
                modifier = Modifier.weight(1f).height(56.dp)
            ) {
                Icon(Icons.Rounded.Casino, null, Modifier.rotate(rot))
                Spacer(Modifier.width(8.dp))
                Text("Придумать!")
            }
            FilledTonalButton(
                onClick = { vm.addItem(idea, Kind.PLAN, null); added = true },
                enabled = !added,
                modifier = Modifier.height(56.dp)
            ) {
                Icon(if (added) Icons.Rounded.Check else Icons.Rounded.Favorite, null)
                Spacer(Modifier.width(8.dp))
                Text(if (added) "В планах" else "В планы")
            }
        }
    }
}

// ───────────────────────── Диалоги ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddItemDialog(kind: Kind, onDismiss: () -> Unit, onAdd: (String, Long?) -> Unit) {
    var text by remember { mutableStateOf("") }
    val canTime = kind != Kind.PLAN
    var remind by remember { mutableStateOf(canTime) }
    var tomorrow by remember { mutableStateOf(false) }
    val now = remember { Calendar.getInstance() }
    val ts = rememberTimePickerState(
        initialHour = (now.get(Calendar.HOUR_OF_DAY) + 1) % 24, initialMinute = 0, is24Hour = true
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when (kind) {
                    Kind.REMINDER -> "Новое напоминание"
                    Kind.PLAN -> "Новый план"
                    Kind.SAY -> "Что не забыть сказать?"
                }
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text("Текст") },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                if (canTime) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Напомнить", Modifier.weight(1f))
                        Switch(checked = remind, onCheckedChange = { remind = it })
                    }
                    AnimatedVisibility(remind) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(!tomorrow, { tomorrow = false }, { Text("Сегодня") })
                                FilterChip(tomorrow, { tomorrow = true }, { Text("Завтра") })
                            }
                            TimeInput(state = ts)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = text.isNotBlank(),
                onClick = {
                    val time: Long? = if (canTime && remind) {
                        val c = Calendar.getInstance()
                        c.set(Calendar.HOUR_OF_DAY, ts.hour)
                        c.set(Calendar.MINUTE, ts.minute)
                        c.set(Calendar.SECOND, 0)
                        c.set(Calendar.MILLISECOND, 0)
                        if (tomorrow || c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
                        c.timeInMillis
                    } else null
                    onAdd(text.trim(), time)
                }
            ) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun AddHabitDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf("💪") }
    val emojis = listOf("💪", "📚", "🧘", "💧", "🚶", "🥗", "😴", "💌", "🌿", "🎶")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая привычка") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("Название") },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    emojis.forEach { e ->
                        FilterChip(selected = e == emoji, onClick = { emoji = e }, label = { Text(e, fontSize = 18.sp) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onAdd(name.trim(), emoji) }) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
