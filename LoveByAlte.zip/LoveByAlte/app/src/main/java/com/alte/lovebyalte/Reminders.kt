package com.alte.lovebyalte

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

object Notifier {
    const val CHANNEL = "love_channel"
    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Напоминания LoveByAlte", NotificationManager.IMPORTANCE_HIGH)
        )
    }
}

object Scheduler {
    fun schedule(ctx: Context, item: Item) {
        val t = item.time ?: return
        if (item.done || t <= System.currentTimeMillis()) return
        val intent = Intent(ctx, ReminderReceiver::class.java)
            .putExtra("text", item.text)
            .putExtra("kind", item.kind.name)
            .putExtra("id", item.id)
        val pi = PendingIntent.getBroadcast(
            ctx, item.id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        ctx.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
    }

    fun cancel(ctx: Context, id: Long) {
        val pi = PendingIntent.getBroadcast(
            ctx, id.toInt(), Intent(ctx, ReminderReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        ) ?: return
        ctx.getSystemService(AlarmManager::class.java).cancel(pi)
        pi.cancel()
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: return
        val kind = intent.getStringExtra("kind")
        val id = intent.getLongExtra("id", 0L)
        Notifier.ensureChannel(ctx)
        val title = if (kind == Kind.SAY.name) "💬 Не забудь сказать" else "💌 Напоминание"
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, Notifier.CHANNEL)
            .setSmallIcon(R.drawable.ic_heart)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(id.toInt(), n)
        } catch (_: SecurityException) {
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Store.loadItems(ctx).forEach { Scheduler.schedule(ctx, it) }
        }
    }
}
