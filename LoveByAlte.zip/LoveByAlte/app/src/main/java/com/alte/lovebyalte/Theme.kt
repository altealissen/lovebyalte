package com.alte.lovebyalte

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val LightFallback = lightColorScheme(
    primary = Color(0xFFB4235B), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFD9E2), onPrimaryContainer = Color(0xFF3E001D),
    secondaryContainer = Color(0xFFFFD9E2), tertiaryContainer = Color(0xFFFFDBCB),
    background = Color(0xFFFFF8F8), surface = Color(0xFFFFF8F8)
)
private val DarkFallback = darkColorScheme(
    primary = Color(0xFFFFB1C8), onPrimary = Color(0xFF650033),
    primaryContainer = Color(0xFF8E0B47), onPrimaryContainer = Color(0xFFFFD9E2),
    secondaryContainer = Color(0xFF5B3F48), tertiaryContainer = Color(0xFF633B2A),
    background = Color(0xFF191113), surface = Color(0xFF191113)
)

@Composable
fun LoveTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> DarkFallback
        else -> LightFallback
    }
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(36.dp)
        ),
        content = content
    )
}
