package com.alte.lovebyalte

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class AppVm(app: Application) : AndroidViewModel(app) {
    var items by mutableStateOf(Store.loadItems(app))
        private set
    var habits by mutableStateOf(Store.loadHabits(app))
        private set

    private val ctx get() = getApplication<Application>()
    private fun persist() = Store.save(ctx, items, habits)

    fun addItem(text: String, kind: Kind, time: Long?) {
        val it = Item(System.currentTimeMillis(), text, kind, false, time)
        items = items + it
        Scheduler.schedule(ctx, it)
        persist()
    }

    fun toggle(id: Long) {
        items = items.map { if (it.id == id) it.copy(done = !it.done) else it }
        val i = items.first { it.id == id }
        if (i.done) Scheduler.cancel(ctx, id) else Scheduler.schedule(ctx, i)
        persist()
    }

    fun delete(id: Long) {
        Scheduler.cancel(ctx, id)
        items = items.filter { it.id != id }
        persist()
    }

    fun addHabit(name: String, emoji: String) {
        habits = habits + Habit(System.currentTimeMillis(), name, emoji)
        persist()
    }

    fun toggleDay(id: Long, date: String) {
        habits = habits.map {
            if (it.id == id) it.copy(days = if (date in it.days) it.days - date else it.days + date) else it
        }
        persist()
    }

    fun deleteHabit(id: Long) {
        habits = habits.filter { it.id != id }
        persist()
    }
}
