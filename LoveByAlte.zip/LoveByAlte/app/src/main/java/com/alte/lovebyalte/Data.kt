package com.alte.lovebyalte

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class Kind { REMINDER, PLAN, SAY }

data class Item(
    val id: Long,
    val text: String,
    val kind: Kind,
    val done: Boolean = false,
    val time: Long? = null
)

data class Habit(
    val id: Long,
    val name: String,
    val emoji: String,
    val days: Set<String> = emptySet()
)

object Store {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("lovebyalte", Context.MODE_PRIVATE)

    fun loadItems(ctx: Context): List<Item> = runCatching {
        val arr = JSONArray(prefs(ctx).getString("items", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Item(
                o.getLong("id"), o.getString("text"), Kind.valueOf(o.getString("kind")),
                o.getBoolean("done"), if (o.has("time")) o.getLong("time") else null
            )
        }
    }.getOrDefault(emptyList())

    fun loadHabits(ctx: Context): List<Habit> = runCatching {
        val arr = JSONArray(prefs(ctx).getString("habits", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val d = o.getJSONArray("days")
            Habit(
                o.getLong("id"), o.getString("name"), o.getString("emoji"),
                (0 until d.length()).map { i -> d.getString(i) }.toSet()
            )
        }
    }.getOrDefault(emptyList())

    fun save(ctx: Context, items: List<Item>, habits: List<Habit>) {
        val ia = JSONArray()
        items.forEach {
            val o = JSONObject()
                .put("id", it.id).put("text", it.text)
                .put("kind", it.kind.name).put("done", it.done)
            if (it.time != null) o.put("time", it.time)
            ia.put(o)
        }
        val ha = JSONArray()
        habits.forEach {
            ha.put(
                JSONObject().put("id", it.id).put("name", it.name)
                    .put("emoji", it.emoji).put("days", JSONArray(it.days.toList()))
            )
        }
        prefs(ctx).edit().putString("items", ia.toString()).putString("habits", ha.toString()).apply()
    }
}
